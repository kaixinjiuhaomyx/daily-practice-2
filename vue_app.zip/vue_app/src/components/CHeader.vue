<template>
    <div>
        <header >
            <span>首页</span>
            <h4>电影</h4>
        </header>

    </div>
</template>

<script>
    export default {
        
    }
</script>

<style scoped>
    header{
        height: 1rem;
        position:fixed;
        top:0px;
        left:0px;
        width:100%;
        background: #ff0036;
        text-align: center;
        line-height: 1rem;
        color:#fff;
    }
    span{
        position: absolute;
        top: 0px;
        left:0.15rem;
    }
</style>